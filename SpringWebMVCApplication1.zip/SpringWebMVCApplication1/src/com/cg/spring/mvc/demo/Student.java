package com.cg.spring.mvc.demo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class Student {
private int studentId;
@Pattern(regexp="[A-Z][a-z]{4,}",
message="Name should start with upper case and should contain only alphabets")
private String firstName; 
private String lastName;
@Pattern(regexp="[0-9] {10}", message="Mobile no should be of 10 digits")
private String mobileNo;
@Min(value=18, message = "Age should be > 18")
@Max(value=50, message= "Age should be < 50")
private int age; 
@NotNull(message="Please select the gender")
private String gender;
@NotNull(message="Please select the city")
private String city;
public int getStudentId() {
	return studentId;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

}
