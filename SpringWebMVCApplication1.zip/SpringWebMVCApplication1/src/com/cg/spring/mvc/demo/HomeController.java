package com.cg.spring.mvc.demo;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class HomeController {
	@RequestMapping("/displayDate")
public String displayDate(Model model) {
		System.out.println("in display date method..");
	LocalDate date = LocalDate.now();
model.addAttribute("today",date);
	return "home";
}
	@RequestMapping("showLoginPage")
	public String getLoginPage() {
		return "login";
	}
	@RequestMapping("loginAction")
	public String validateUser(Model model,
			@RequestParam("user")String uname,
			@RequestParam("pwd")String psw) {
		if(uname.equals("Dinesh")&&psw.equals("dinu"))
				{
		model.addAttribute("successMsg", "Welcome to home page");
		
		model.addAttribute("user", uname);
		LocalDate date = LocalDate.now();
		model.addAttribute("today",date);
		return "home";
	}
		else
		{
			model.addAttribute("errorMsg", "invalid user name and password");
			return "error";
		}
	
}
	@RequestMapping("showRegistrationPage")
	public String getRegistrationPage(Model model) {
		Student student = new Student();
		model.addAttribute("studentBean",student);
		return "person";
	}
	@RequestMapping("registerAction")
	public String registerUser(Model model,
			 @ModelAttribute("studentBean") 
	@Valid Student student, BindingResult result) {
		if(result.hasErrors())
		{
			
			return "person";
		}else {
		model.addAttribute("student", student);
		return "success";
		}
	}
}